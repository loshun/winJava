package com.tts.week13day4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week13day4Application {

	public static void main(String[] args) {
		SpringApplication.run(Week13day4Application.class, args);
	}

}
