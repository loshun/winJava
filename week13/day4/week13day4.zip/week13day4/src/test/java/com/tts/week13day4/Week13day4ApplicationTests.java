package com.tts.week13day4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week13day4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
